import flet as ft
from flet import *
import requests
import json

players_url = "https://fantasy.premierleague.com/api/bootstrap-static/"

p = requests.get(players_url)

Players_data = p.json()
def main(page : Page):

    page.scroll = "auto"
    


    page.horizontal_alignment = "center"
    page.vertical_alignment = "center"


    def btn_click(e):
            if not ID.value:
                ID.error_text = "Please enter your ID"
                page.update()
                
            else:
                
                name = ID.value
                picks = f"https://fantasy.premierleague.com/api/entry/{name}/event/1/picks/"
                manger = f"https://fantasy.premierleague.com/api/entry/{name}"
                r = requests.get(picks)
                ru = requests.get(manger)
                picks_data = r.json()
                manger_data = ru.json()
                def _appli():
                        appli = Container(
                            width=310,
                            height=300 * 0.40,
                            gradient=LinearGradient(
                                begin=alignment.bottom_left,
                                end=alignment.top_right,
                                colors=['lightblue660' , 'lightblue900']
                            ),
                            border_radius=35,
                            content=Column(
                                alignment='start',
                                spacing=10,
                                controls=[
                                    Row(
                                        alignment='center',
                                        controls=[
                                            Text(
                                                f"{manger_data['name']}",
                                                size=40
                                            )]),
                                    Row(
                                        alignment='center',
                                        controls=[
                                            Text(
                                                "Total : ",
                                                size=25
                                            ),
                                            Text(
                                                manger_data['summary_event_points'],
                                                size=30
                                            )]),
                                    Row(
                                        
                                    )
                                ]
                            )
                        )
                        return appli
                _c = Container(
                            width=310,
                            # height=660,
                            border_radius=35,
                            bgcolor='black',
                            padding=10,
                            content=Stack(
                                width=300,controls=[_appli()]
                            )
                        )
    
                page.clean()
                def bt(e):
                    page.clean()
                    main(page)
                page.add(ft.ElevatedButton("Back", on_click=bt))
                page.add(_c)
                for i in picks_data['picks']:
                    # print(i['element'])
                    for u in Players_data['elements']:
                        if u['id'] == i['element']:
                            imga = u['photo'][:-4]
                            img = ft.Image(
                                src=f"https://resources.premierleague.com/premierleague/photos/players/250x250/p{imga}.png",
                                width=200,
                                height=200,
                                border_radius=10,
                            )
                            page.add(img)
                            page.add(ft.Text(u['web_name']))
                            # print(u['web_name'])
                            page.add(ft.Text(u['event_points']))
                            page.add(ft.Text(u['now_cost'] / 10))
                            page.update()
                

    ID = ft.TextField(label="Your ID" , width=400)

    page.add(ID, ft.ElevatedButton("Show Team", on_click=btn_click))
            
    
    

# ft.app(target=main , view=ft.AppView.WEB_BROWSER)
if __name__ == "__main__":
    ft.app(target=main , assets_dir="assets")